package com.example.newu.branokod3;

public class List {
    private String heading;
    private String Desc;

    public List(String heading, String desc) {
        this.heading = heading;
        Desc = desc;
    }

    public String getHeading() {
        return heading;
    }

    public String getDesc() {
        return Desc;
    }
}
