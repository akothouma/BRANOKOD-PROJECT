package com.example.newu.branokod3;

public class PotentialC {
    String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public PotentialC(){}
}
